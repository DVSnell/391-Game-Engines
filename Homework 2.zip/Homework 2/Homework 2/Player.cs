﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework_2
{
    class Player
    {
        static public string playerName = "Name";
        static public string favGame = "Game";
        static public int ageUser = 0;
        static public int ageSum = 0;
        static public int difficulty = 20;
        static public int score = 0;
    }
}
